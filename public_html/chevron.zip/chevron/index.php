<?php
	include_once 'header.php';
?>
<div class="central-container">
        <div class="row">
            <div class="col">
                <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-semilight">
					<div class="col-md-12 p-lg-5 mx-auto my-5">
					<h1 class="display-4 font-weight-normal">Chevron Edit</h1>
						<p class="lead font-weight-normal">Currently forcing the signup page to 
							have an error to prevent additional 
							login creations.  If login information 
							is needed, contact me.</p>
					</div>
				</div>
			</div>
		</div>
</div>

<?php
	include_once 'footer.php';
?>